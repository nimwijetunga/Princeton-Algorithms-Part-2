import java.awt.Color;

import edu.princeton.cs.algs4.AcyclicSP;
import edu.princeton.cs.algs4.DirectedEdge;
import edu.princeton.cs.algs4.EdgeWeightedDigraph;
import edu.princeton.cs.algs4.Picture;

public class SeamCarver {
	
   private Picture picture;
	
   public SeamCarver(Picture picture)  {
	   if(picture == null) {
		   throw new java.lang.IllegalArgumentException("Null Picture!");
	   }
	   this.picture = picture;
   }              // create a seam carver object based on the given picture
   
   public Picture picture() {
	   return this.picture;
   }                          // current picture
   
   public int width() {
	   return this.picture.width();
   }                           // width of current picture
   public int height()  {
	   return this.picture.height();
   }                         // height of current picture
   
   private double sqr(int x) {
	   return Math.pow(x, 2);
   }
   
   private double grad(Color one, Color two) {
	   return sqr(one.getRed() - two.getRed()) + sqr(one.getGreen() - two.getGreen()) + sqr(one.getBlue() - two.getBlue()); 
   }
   
   public double energy(int x, int y)   {
	   if(x < 0 || x >= this.width() || y < 0 || y >= this.height()) {
		   throw new java.lang.IllegalArgumentException("Invalid (x,y) pair!");
	   }
	   if(x == 0 || y == 0 || x == this.width() - 1 || y == this.height() - 1) {
		   return 1000;
	   }
	   double xGrad = grad(this.picture.get(x + 1, y), this.picture.get(x - 1, y));
	   double yGrad = grad(this.picture.get(x, y + 1), this.picture.get(x, y - 1));
	   return Math.sqrt(xGrad + yGrad);
   }            // energy of pixel at column x and row y
   
   private boolean inBounds(int x, int y) {
	   if(x < 0 || x >= this.width() || y < 0 || y >= this.height()) {
		   return false;
	   }
	   return true;
   }
   
   private int getIndex(int i, int j, int numCol) {
	   return j * numCol + i;
   }
   
   private EdgeWeightedDigraph createGraphVert(Picture picture) {
	   int width = picture.width(), height = picture.height();
	   EdgeWeightedDigraph dg = new EdgeWeightedDigraph(width * height);
	   for(int i = 0 ; i < width; i++) {
		   for(int j = 0; j < height; j++) {
			   int tail = getIndex(i,j,width);
			   if(inBounds(i, j + 1)) {
				   dg.addEdge(new DirectedEdge(tail, getIndex(i, j+1,width), energy(i,j+1)));
			   }
			   if(inBounds(i + 1, j + 1)) {
				   dg.addEdge(new DirectedEdge(tail, getIndex(i+1,j+1,width), energy(i+1,j+1)));
			   }
			   if(inBounds(i - 1, j + 1)) {
				   dg.addEdge(new DirectedEdge(tail, getIndex(i-1,j+1,width), energy(i-1,j+1)));
			   }
		   }
	   }
	   return dg;
   }
   
   private EdgeWeightedDigraph createGraphHoriz(Picture picture) {
	   int width = picture.width(), height = picture.height();
	   EdgeWeightedDigraph dg = new EdgeWeightedDigraph(width * height);
	   for(int i = 0 ; i < width; i++) {
		   for(int j = 0; j < height; j++) {
			   int tail = getIndex(i,j,width);
			   if(inBounds(i + 1, j)) {
				   dg.addEdge(new DirectedEdge(tail, getIndex(i+1, j,width), energy(i+1,j)));
			   }
			   if(inBounds(i + 1, j + 1)) {
				   dg.addEdge(new DirectedEdge(tail, getIndex(i+1,j+1,width), energy(i+1,j+1)));
			   }
			   if(inBounds(i + 1, j - 1)) {
				   dg.addEdge(new DirectedEdge(tail, getIndex(i+1,j-1,width), energy(i+1,j-1)));
			   }
		   }
	   }
	   return dg;
   }
   
   public int[] findHorizontalSeam() {
	   AcyclicSP sp;
	   EdgeWeightedDigraph dg = createGraphHoriz(this.picture);
	   double minDistTot = Double.MAX_VALUE;
	   int seam[] = new int[this.width()];
	   Iterable<DirectedEdge> edges = null;
	   for(int i = 0; i < this.height(); i++) {
		   sp = new AcyclicSP(dg,i*this.width());
		   double minDist = Double.MAX_VALUE;
		   Iterable<DirectedEdge> edgesLocal = null;
		   for(int j = 0; j < this.height(); j++) {
			   int vertex = j * this.width() + (this.width() - 1);
			   if(sp.distTo(vertex) < minDist) {
				   minDist = sp.distTo(vertex);
				   edgesLocal = sp.pathTo(vertex);
			   }
		   }
		   if(minDist < minDistTot) {
			   edges = edgesLocal;
			   minDistTot = minDist;
		   }
	   }
	   if(edges != null) {
		   int count = 0;
		   DirectedEdge eCur = null;
		   for(DirectedEdge e : edges) {
			   eCur = e;
			   seam[count] = e.from() / this.width();
			   count++;
		   }
		   if(eCur != null) {
			   seam[this.width() - 1] = eCur.to() / this.width();
		   }
	   }
	   return seam;
   }             // sequence of indices for horizontal seam
   
   public int[] findVerticalSeam() {
	   AcyclicSP sp;
	   EdgeWeightedDigraph dg = createGraphVert(this.picture);
	   double minDistTot = Double.MAX_VALUE;
	   int seam[] = new int[this.height()];
	   Iterable<DirectedEdge> edges = null;
	   for(int i = 0; i < this.width(); i++) {
		   sp = new AcyclicSP(dg,i);
		   double minDist = Double.MAX_VALUE;
		   Iterable<DirectedEdge> edgesLocal = null;
		   for(int j = 0; j < this.width(); j++) {
			   int vertex = (this.height() - 1) * this.width() + j;
			   if(sp.distTo(vertex) < minDist) {
				   minDist = sp.distTo(vertex);
				   edgesLocal = sp.pathTo(vertex);
			   }
		   }
		   if(minDist < minDistTot) {
			   edges = edgesLocal;
			   minDistTot = minDist;
		   }
	   }
	   if(edges != null) {
		   int count = 0;
		   DirectedEdge eCur = null;
		   for(DirectedEdge e : edges) {
			   eCur = e;
			   seam[count] = e.from() % this.width();
			   count++;
		   }
		   if(eCur != null) {
			   seam[this.height() - 1] = eCur.to() % this.width();
		   }
	   }
	   return seam;
   }                // sequence of indices for vertical seam
   
   public void removeHorizontalSeam(int[] seam) {
	   if(seam == null || seam.length != this.width() || this.height() <= 1) {
		   throw new java.lang.IllegalArgumentException("Invalid Seam Array!");
	   }
	   
	   for (int i = 1; i < this.width(); i++)
		      if (Math.abs(seam[i] - seam[i - 1]) > 1)
		        throw new IllegalArgumentException("absolute difference is not at most 1!");
	   
	   Picture newPic = new Picture(this.width(), this.height() - 1);
	   for(int i = 0; i < this.width(); i++) {
		   int k = 0;
		   for(int j = 0; j < this.height(); j++) {
			   if(seam[i] != j) {
				   newPic.setRGB(i, k++, this.picture.getRGB(i, j));
			   }
		   }
	   }
	   this.picture = newPic;
   }   // remove horizontal seam from current picture
   
   public void removeVerticalSeam(int[] seam) {
	   if(seam == null || seam.length != this.height() || this.width() <= 1) {
		   throw new java.lang.IllegalArgumentException("Invalid Seam Array!");
	   }
	   
	   for (int i = 1; i < this.height(); i++)
		      if (Math.abs(seam[i] - seam[i - 1]) > 1)
		        throw new IllegalArgumentException("absolute difference is not at most 1!");
	   
	   Picture newPic = new Picture(this.width() - 1, this.height());
	   for(int i = 0; i < this.height(); i++) {
		   int k = 0;
		   for(int j = 0; j < this.width(); j++) {
			   if(seam[i] != j) {
				   newPic.setRGB(k++, j, this.picture.getRGB(i, j));
			   }
		   }
	   }
	   this.picture = newPic;
   }     // remove vertical seam from current picture
   
   public static void main(String [] args) {
//	   SeamCarver sc = new SeamCarver(new Picture("8x1.png"));
//	   System.out.println(sc.createGraphVert(new Picture("8x1.png")));
//	   int [] seam = sc.findVerticalSeam();
//	   sc.removeHorizontalSeam(seam);
//	   for(int i : seam) {
//		   System.out.println(i);
//	   }
   }
}